-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema updatedbowlingleagueexample
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema updatedbowlingleagueexample
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `updatedbowlingleagueexample` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `updatedbowlingleagueexample` ;

-- -----------------------------------------------------
-- Table `updatedbowlingleagueexample`.`teams`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`teams` (
  `TeamID` INT NOT NULL DEFAULT '0',
  `TeamName` VARCHAR(50) CHARACTER SET 'utf8' NOT NULL,
  `CaptainID` INT NULL DEFAULT NULL,
  PRIMARY KEY (`TeamID`),
  UNIQUE INDEX `TeamID` (`TeamID` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `updatedbowlingleagueexample`.`bowlers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`bowlers` (
  `BowlerID` INT NOT NULL AUTO_INCREMENT,
  `BowlerLastName` VARCHAR(50) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `BowlerFirstName` VARCHAR(50) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `BowlerMiddleInit` VARCHAR(1) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `BowlerAddress` VARCHAR(50) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `BowlerCity` VARCHAR(50) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `BowlerState` VARCHAR(2) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `BowlerZip` VARCHAR(10) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `BowlerPhoneNumber` VARCHAR(14) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `TeamID` INT NULL DEFAULT NULL,
  PRIMARY KEY (`BowlerID`),
  INDEX `BowlerLastName` (`BowlerLastName` ASC) VISIBLE,
  INDEX `BowlersTeamID` (`TeamID` ASC) VISIBLE,
  UNIQUE INDEX `BowlerID_UNIQUE` (`BowlerID` ASC) VISIBLE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `updatedbowlingleagueexample`.`tournaments`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`tournaments` (
  `TourneyID` INT NOT NULL DEFAULT '0',
  `TourneyDate` DATE NULL DEFAULT NULL,
  `TourneyLocation` VARCHAR(50) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  PRIMARY KEY (`TourneyID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `updatedbowlingleagueexample`.`tourney_matches`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`tourney_matches` (
  `MatchID` INT NOT NULL DEFAULT '0',
  `TourneyID` INT NULL DEFAULT '0',
  `Lanes` VARCHAR(5) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `OddLaneTeamID` INT NULL DEFAULT '0',
  `EvenLaneTeamID` INT NULL DEFAULT '0',
  PRIMARY KEY (`MatchID`),
  INDEX `Tourney_MatchesEven` (`EvenLaneTeamID` ASC) VISIBLE,
  INDEX `TourneyMatchesOdd` (`OddLaneTeamID` ASC) VISIBLE,
  INDEX `TourneyMatchesTourneyID` (`TourneyID` ASC) VISIBLE,
  CONSTRAINT `Tourney_Matches_FK00`
    FOREIGN KEY (`EvenLaneTeamID`)
    REFERENCES `updatedbowlingleagueexample`.`teams` (`TeamID`),
  CONSTRAINT `Tourney_Matches_FK01`
    FOREIGN KEY (`OddLaneTeamID`)
    REFERENCES `updatedbowlingleagueexample`.`teams` (`TeamID`),
  CONSTRAINT `Tourney_Matches_FK02`
    FOREIGN KEY (`TourneyID`)
    REFERENCES `updatedbowlingleagueexample`.`tournaments` (`TourneyID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `updatedbowlingleagueexample`.`match_games`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`match_games` (
  `MatchID` INT NOT NULL DEFAULT '0',
  `GameNumber` SMALLINT NOT NULL DEFAULT '0',
  `WinningTeamID` INT NULL DEFAULT '0',
  PRIMARY KEY (`MatchID`, `GameNumber`),
  INDEX `Team1ID` (`WinningTeamID` ASC) VISIBLE,
  INDEX `TourneyMatchesMatchGames` (`MatchID` ASC) VISIBLE,
  CONSTRAINT `Match_Games_FK00`
    FOREIGN KEY (`MatchID`)
    REFERENCES `updatedbowlingleagueexample`.`tourney_matches` (`MatchID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `updatedbowlingleagueexample`.`bowler_scores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`bowler_scores` (
  `MatchID` INT NOT NULL DEFAULT '0',
  `GameNumber` SMALLINT NOT NULL DEFAULT '0',
  `BowlerID` INT NOT NULL DEFAULT '0',
  `RawScore` SMALLINT NULL DEFAULT '0',
  `HandiCapScore` SMALLINT NULL DEFAULT '0',
  `WonGame` BIT(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`MatchID`, `GameNumber`, `BowlerID`),
  INDEX `BowlerID` (`BowlerID` ASC) VISIBLE,
  INDEX `MatchGamesBowlerScores` (`MatchID` ASC, `GameNumber` ASC) VISIBLE,
  CONSTRAINT `Bowler_Scores_FK00`
    FOREIGN KEY (`BowlerID`)
    REFERENCES `updatedbowlingleagueexample`.`bowlers` (`BowlerID`),
  CONSTRAINT `Bowler_Scores_FK01`
    FOREIGN KEY (`MatchID` , `GameNumber`)
    REFERENCES `updatedbowlingleagueexample`.`match_games` (`MatchID` , `GameNumber`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `updatedbowlingleagueexample`.`ztblbowlerratings`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ztblbowlerratings` (
  `BowlerRating` VARCHAR(15) CHARACTER SET 'utf8' NOT NULL,
  `BowlerLowAvg` SMALLINT NULL DEFAULT NULL,
  `BowlerHighAvg` SMALLINT NULL DEFAULT NULL,
  PRIMARY KEY (`BowlerRating`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `updatedbowlingleagueexample`.`ztblskiplabels`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ztblskiplabels` (
  `LabelCount` INT NOT NULL,
  PRIMARY KEY (`LabelCount`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `updatedbowlingleagueexample`.`ztblweeks`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ztblweeks` (
  `WeekStart` DATE NOT NULL,
  `WeekEnd` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`WeekStart`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;

USE `updatedbowlingleagueexample` ;

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch04_bowler_names_addresses`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch04_bowler_names_addresses` (`BowlerLastName` INT, `BowlerFirstName` INT, `BowlerAddress` INT, `BowlerCity` INT, `BowlerState` INT, `BowlerZip` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch04_bowler_score_information`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch04_bowler_score_information` (`MatchID` INT, `GameNumber` INT, `BowlerID` INT, `RawScore` INT, `HandiCapScore` INT, `WonGame` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch04_team_list`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch04_team_list` (`TeamName` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch04_tourney_dates`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch04_tourney_dates` (`TourneyDate` INT, `TourneyLocation` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch04_tourney_locations`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch04_tourney_locations` (`TourneyLocation` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch05_handicap_vs_rawscore`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch05_handicap_vs_rawscore` (`BowlerID` INT, `MatchID` INT, `GameNumber` INT, `HandiCapScore` INT, `RawScore` INT, `PointDifference` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch05_names_address_for_mailing`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch05_names_address_for_mailing` (`FullName` INT, `BowlerAddress` INT, `CityStateZip` INT, `BowlerZip` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch05_next_years_tourney_dates`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch05_next_years_tourney_dates` (`TourneyLocation` INT, `TourneyDate` INT, `NextYearTourneyDate` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch05_phone_list`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch05_phone_list` (`Bowler` INT, `Phone` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch05_team_lineups`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch05_team_lineups` (`TeamID` INT, `Bowler` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch06_eastside_bowlers_on_teams_5_through_8`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch06_eastside_bowlers_on_teams_5_through_8` (`BowlerFirstName` INT, `BowlerLastName` INT, `BowlerCity` INT, `TeamID` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch06_eastside_tournaments`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch06_eastside_tournaments` (`TourneyLocation` INT, `TourneyDate` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch06_game3_top_ten_matches`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch06_game3_top_ten_matches` (`WinningTeamID` INT, `MatchID` INT, `GameNumber` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch06_h_bowlers_teams_3_through_5`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch06_h_bowlers_teams_3_through_5` (`BowlerFirstName` INT, `BowlerLastName` INT, `TeamID` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch06_september_2017_tournament_schedule`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch06_september_2017_tournament_schedule` (`TourneyDate` INT, `TourneyLocation` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch08_bowler_game_scores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch08_bowler_game_scores` (`MatchID` INT, `TeamName` INT, `BowlerFullName` INT, `GameNumber` INT, `RawScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch08_bowlers_same_zipcode`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch08_bowlers_same_zipcode` (`FirstBowler` INT, `BowlerZip` INT, `SecondBowler` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch08_good_bowlers_tbird_and_bolero`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch08_good_bowlers_tbird_and_bolero` (`BowlerFullName` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch08_teams_and_bowlers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch08_teams_and_bowlers` (`TeamName` INT, `BowlerFullName` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch08_teams_and_captains`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch08_teams_and_captains` (`TeamName` INT, `CaptainName` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch08_tournament_match_game_results`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch08_tournament_match_game_results` (`Tourney` INT, `Location` INT, `MatchID` INT, `Lanes` INT, `OddLaneTeam` INT, `EvenLaneTeam` INT, `GameNo` INT, `Winner` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch09_all_bowlers_and_scores_over_180`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch09_all_bowlers_and_scores_over_180` (`BowlerName` INT, `TourneyDate` INT, `TourneyLocation` INT, `MatchID` INT, `RawScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch09_all_tourneys_match_results`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch09_all_tourneys_match_results` (`TourneyID` INT, `TourneyDate` INT, `TourneyLocation` INT, `MatchID` INT, `GameNumber` INT, `Winner` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch09_matches_not_played_yet`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch09_matches_not_played_yet` (`MatchID` INT, `TourneyID` INT, `OddLaneTeam` INT, `EvenLaneTeam` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch09_tourney_not_yet_played`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch09_tourney_not_yet_played` (`TourneyID` INT, `TourneyDate` INT, `TourneyLocation` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch10_bowling_schedule`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch10_bowling_schedule` (`TourneyLocation` INT, `TourneyDate` INT, `MatchID` INT, `TeamName` INT, `Captain` INT, `Lane` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_union`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_union` (`TourneyLocation` INT, `BowlerLastName` INT, `BowlerFirstName` INT, `RawScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_where`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_where` (`TourneyLocation` INT, `BowlerLastName` INT, `BowlerFirstName` INT, `RawScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch11_bowler_high_score`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch11_bowler_high_score` (`BowlerFirstName` INT, `BowlerLastName` INT, `HighScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch11_bowlers_and_count_games`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch11_bowlers_and_count_games` (`BowlerFirstName` INT, `BowlerLastName` INT, `Games` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch11_bowlers_low_score`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch11_bowlers_low_score` (`BowlerID` INT, `BowlerFirstName` INT, `BowlerLastName` INT, `RawScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch11_team_captains_high_score`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch11_team_captains_high_score` (`TeamName` INT, `BowlerID` INT, `BowlerFirstName` INT, `BowlerLastName` INT, `HandiCapScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch12_better_than_overall_average`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch12_better_than_overall_average` (`BowlerLastName` INT, `BowlerFirstName` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch12_current_highest_handicap`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch12_current_highest_handicap` (`HighHandicap` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch12_last_tourney_date`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch12_last_tourney_date` (`MostRecentDate` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch12_number_of_tournaments_at_red_rooster_lanes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch12_number_of_tournaments_at_red_rooster_lanes` (`NumberOfTournaments` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch12_tourney_locations_for_earliest_date`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch12_tourney_locations_for_earliest_date` (`TourneyLocation` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch13_bowler_average_handicap`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch13_bowler_average_handicap` (`BowlerID` INT, `BowlerLastName` INT, `BowlerFirstName` INT, `TotalPins` INT, `GamesBowled` INT, `CurAvg` INT, `CurHcp` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch13_bowler_averages`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch13_bowler_averages` (`BowlerFullName` INT, `AvgOfRawScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch13_bowler_high_score_group`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch13_bowler_high_score_group` (`BowlerFirstName` INT, `BowlerLastName` INT, `HighScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch13_bowler_high_score_subquery`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch13_bowler_high_score_subquery` (`BowlerFirstName` INT, `BowlerLastName` INT, `HighScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch13_tournament_match_team_results`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch13_tournament_match_team_results` (`TourneyID` INT, `TourneyLocation` INT, `MatchID` INT, `TeamName` INT, `TotHandiCapScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch14_better_than_overall_average_having`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch14_better_than_overall_average_having` (`BowlerLastName` INT, `BowlerFirstName` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch14_bowlers_big_high_score`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch14_bowlers_big_high_score` (`BowlerFirstName` INT, `BowlerLastName` INT, `CurrentAverage` INT, `HighGame` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch14_captains_who_are_hotshots`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch14_captains_who_are_hotshots` (`TeamID` INT, `BowlerID` INT, `BowlerFirstName` INT, `BowlerLastName` INT, `MaxOfRawScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch14_good_bowlers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch14_good_bowlers` (`BowlerFirstName` INT, `BowlerLastName` INT, `AvgScore` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch18_bowlers_lte_165_thunderbird_bolero`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch18_bowlers_lte_165_thunderbird_bolero` (`BowlerID` INT, `BowlerLastName` INT, `BowlerFirstName` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_right`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_right` (`BowlerID` INT, `BowlerFirstName` INT, `BowlerLastName` INT, `MatchID` INT, `GameNumber` INT, `HandiCapScore` INT, `TourneyDate` INT, `TourneyLocation` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_wrong`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_wrong` (`BowlerID` INT, `BowlerFirstName` INT, `BowlerLastName` INT, `MatchID` INT, `GameNumber` INT, `HandiCapScore` INT, `TourneyDate` INT, `TourneyLocation` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch18_good_bowlers_tbird_and_bolero_exists`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch18_good_bowlers_tbird_and_bolero_exists` (`BowlerID` INT, `BowlerLastName` INT, `BowlerFirstName` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch18_mediocre_bowlers`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch18_mediocre_bowlers` (`BowlerID` INT, `BowlerFirstName` INT, `BowlerLastName` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch18_tourney_not_yet_played_not_in`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch18_tourney_not_yet_played_not_in` (`TourneyID` INT, `TourneyDate` INT, `TourneyLocation` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch19_all_tournaments_any_matches`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch19_all_tournaments_any_matches` (`TourneyID` INT, `TourneyDate` INT, `TourneyLocation` INT, `MatchInfo` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch19_all_tourney_matches`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch19_all_tourney_matches` (`TourneyDate` INT, `TourneyLocation` INT, `Lanes` INT, `MatchID` INT, `OddLaneTeam` INT, `EvenLaneTeam` INT, `GameNumber` INT, `Winner` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch19_bowler_averages_avoid_0_games`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch19_bowler_averages_avoid_0_games` (`BowlerID` INT, `BowlerFirstName` INT, `BowlerLastName` INT, `GamesBowled` INT, `TotalPins` INT, `BowlerAverage` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch19_bowler_ratings`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch19_bowler_ratings` (`BowlerID` INT, `BowlerLastName` INT, `BowlerFirstName` INT, `BowlerAverage` INT, `BowlerRating` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch20_bowler_mailing_skip_3`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch20_bowler_mailing_skip_3` (`BowlerLastName` INT, `BowlerFirstName` INT, `BowlerAddress` INT, `BowlerCity` INT, `BowlerState` INT, `BowlerZip` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch20_bowler_ratings`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch20_bowler_ratings` (`BowlerID` INT, `BowlerLastName` INT, `BowlerFirstName` INT, `BowlerAverage` INT, `BowlerRating` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch20_team_pairings`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch20_team_pairings` (`Team1ID` INT, `Team1Name` INT, `Team2ID` INT, `Team2Name` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch20_tournament_week_schedule_2017`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch20_tournament_week_schedule_2017` (`WeekStart` INT, `BowlingAlley` INT);

-- -----------------------------------------------------
-- Placeholder table for view `updatedbowlingleagueexample`.`ch4_ble_2`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `updatedbowlingleagueexample`.`ch4_ble_2` (`MatchID` INT, `GameNumber` INT, `BowlerID` INT, `RawScore` INT, `HandiCapScore` INT, `WonGame` INT);

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch04_bowler_names_addresses`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch04_bowler_names_addresses`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch04_bowler_names_addresses` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerAddress` AS `BowlerAddress`,`updatedbowlingleagueexample`.`bowlers`.`BowlerCity` AS `BowlerCity`,`updatedbowlingleagueexample`.`bowlers`.`BowlerState` AS `BowlerState`,`updatedbowlingleagueexample`.`bowlers`.`BowlerZip` AS `BowlerZip` from `updatedbowlingleagueexample`.`bowlers` order by `updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch04_bowler_score_information`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch04_bowler_score_information`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch04_bowler_score_information` AS select `updatedbowlingleagueexample`.`bowler_scores`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`bowler_scores`.`GameNumber` AS `GameNumber`,`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` AS `RawScore`,`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` AS `HandiCapScore`,`updatedbowlingleagueexample`.`bowler_scores`.`WonGame` AS `WonGame` from `updatedbowlingleagueexample`.`bowler_scores`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch04_team_list`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch04_team_list`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch04_team_list` AS select `updatedbowlingleagueexample`.`teams`.`TeamName` AS `TeamName` from `updatedbowlingleagueexample`.`teams` order by `updatedbowlingleagueexample`.`teams`.`TeamName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch04_tourney_dates`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch04_tourney_dates`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch04_tourney_dates` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation` from `updatedbowlingleagueexample`.`tournaments` order by `updatedbowlingleagueexample`.`tournaments`.`TourneyDate` desc,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch04_tourney_locations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch04_tourney_locations`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch04_tourney_locations` AS select distinct `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation` from `updatedbowlingleagueexample`.`tournaments`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch05_handicap_vs_rawscore`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch05_handicap_vs_rawscore`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch05_handicap_vs_rawscore` AS select `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowler_scores`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`bowler_scores`.`GameNumber` AS `GameNumber`,`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` AS `HandiCapScore`,`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` AS `RawScore`,(`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` - `updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) AS `PointDifference` from `updatedbowlingleagueexample`.`bowler_scores` order by `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`,`updatedbowlingleagueexample`.`bowler_scores`.`MatchID`,`updatedbowlingleagueexample`.`bowler_scores`.`GameNumber`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch05_names_address_for_mailing`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch05_names_address_for_mailing`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch05_names_address_for_mailing` AS select concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`,' ',`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`) AS `FullName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerAddress` AS `BowlerAddress`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerCity`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerState`,'  ',`updatedbowlingleagueexample`.`bowlers`.`BowlerZip`) AS `CityStateZip`,`updatedbowlingleagueexample`.`bowlers`.`BowlerZip` AS `BowlerZip` from `updatedbowlingleagueexample`.`bowlers` order by `updatedbowlingleagueexample`.`bowlers`.`BowlerZip`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch05_next_years_tourney_dates`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch05_next_years_tourney_dates`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch05_next_years_tourney_dates` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,(`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` + interval 364 day) AS `NextYearTourneyDate` from `updatedbowlingleagueexample`.`tournaments` order by `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch05_phone_list`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch05_phone_list`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch05_phone_list` AS select concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `Bowler`,`updatedbowlingleagueexample`.`bowlers`.`BowlerPhoneNumber` AS `Phone` from `updatedbowlingleagueexample`.`bowlers` order by concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`);

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch05_team_lineups`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch05_team_lineups`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch05_team_lineups` AS select `updatedbowlingleagueexample`.`bowlers`.`TeamID` AS `TeamID`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `Bowler` from `updatedbowlingleagueexample`.`bowlers` order by `updatedbowlingleagueexample`.`bowlers`.`TeamID`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`);

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch06_eastside_bowlers_on_teams_5_through_8`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch06_eastside_bowlers_on_teams_5_through_8`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch06_eastside_bowlers_on_teams_5_through_8` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerCity` AS `BowlerCity`,`updatedbowlingleagueexample`.`bowlers`.`TeamID` AS `TeamID` from `updatedbowlingleagueexample`.`bowlers` where ((`updatedbowlingleagueexample`.`bowlers`.`BowlerCity` in ('Bellevue','Bothell','Duvall','Redmond','Woodinville')) and (`updatedbowlingleagueexample`.`bowlers`.`TeamID` between 5 and 8)) order by `updatedbowlingleagueexample`.`bowlers`.`BowlerCity`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch06_eastside_tournaments`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch06_eastside_tournaments`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch06_eastside_tournaments` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate` from `updatedbowlingleagueexample`.`tournaments` where (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` in ('Red Rooster Lanes','Thunderbird Lanes','Bolero Lanes')) order by `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch06_game3_top_ten_matches`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch06_game3_top_ten_matches`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch06_game3_top_ten_matches` AS select `updatedbowlingleagueexample`.`match_games`.`WinningTeamID` AS `WinningTeamID`,`updatedbowlingleagueexample`.`match_games`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`match_games`.`GameNumber` AS `GameNumber` from `updatedbowlingleagueexample`.`match_games` where ((`updatedbowlingleagueexample`.`match_games`.`MatchID` <= 10) and (`updatedbowlingleagueexample`.`match_games`.`GameNumber` = 3));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch06_h_bowlers_teams_3_through_5`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch06_h_bowlers_teams_3_through_5`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch06_h_bowlers_teams_3_through_5` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`TeamID` AS `TeamID` from `updatedbowlingleagueexample`.`bowlers` where ((`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` like 'H%') and (`updatedbowlingleagueexample`.`bowlers`.`TeamID` in (3,4,5)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch06_september_2017_tournament_schedule`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch06_september_2017_tournament_schedule`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch06_september_2017_tournament_schedule` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation` from `updatedbowlingleagueexample`.`tournaments` where (`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` between cast('2017-9-1' as date) and cast('2017-9-30' as date));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch08_bowler_game_scores`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch08_bowler_game_scores`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch08_bowler_game_scores` AS select `updatedbowlingleagueexample`.`bowler_scores`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`teams`.`TeamName` AS `TeamName`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`,' ',`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`) AS `BowlerFullName`,`updatedbowlingleagueexample`.`bowler_scores`.`GameNumber` AS `GameNumber`,`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` AS `RawScore` from ((`updatedbowlingleagueexample`.`teams` join `updatedbowlingleagueexample`.`bowlers` on((`updatedbowlingleagueexample`.`teams`.`TeamID` = `updatedbowlingleagueexample`.`bowlers`.`TeamID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch08_bowlers_same_zipcode`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch08_bowlers_same_zipcode`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch08_bowlers_same_zipcode` AS select concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `FirstBowler`,`updatedbowlingleagueexample`.`bowlers`.`BowlerZip` AS `BowlerZip`,concat(`bowlers2`.`BowlerLastName`,', ',`bowlers2`.`BowlerFirstName`) AS `SecondBowler` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowlers` `bowlers2` on(((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` <> `bowlers2`.`BowlerID`) and (`updatedbowlingleagueexample`.`bowlers`.`BowlerZip` = `bowlers2`.`BowlerZip`))));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch08_good_bowlers_tbird_and_bolero`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch08_good_bowlers_tbird_and_bolero`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch08_good_bowlers_tbird_and_bolero` AS select `bowlertbird`.`BowlerFullName` AS `BowlerFullName` from ((select distinct `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `BowlerFullName` from (((`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) join `updatedbowlingleagueexample`.`tournaments` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) where ((`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Thunderbird Lanes') and (`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` >= 170))) `bowlertbird` join (select distinct `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `BowlerFullName` from (((`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) join `updatedbowlingleagueexample`.`tournaments` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) where ((`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Bolero Lanes') and (`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` >= 170))) `bowlerbolero` on((`bowlertbird`.`BowlerID` = `bowlerbolero`.`BowlerID`)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch08_teams_and_bowlers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch08_teams_and_bowlers`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch08_teams_and_bowlers` AS select `updatedbowlingleagueexample`.`teams`.`TeamName` AS `TeamName`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `BowlerFullName` from (`updatedbowlingleagueexample`.`teams` join `updatedbowlingleagueexample`.`bowlers` on((`updatedbowlingleagueexample`.`teams`.`TeamID` = `updatedbowlingleagueexample`.`bowlers`.`TeamID`)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch08_teams_and_captains`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch08_teams_and_captains`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch08_teams_and_captains` AS select `updatedbowlingleagueexample`.`teams`.`TeamName` AS `TeamName`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `CaptainName` from (`updatedbowlingleagueexample`.`teams` join `updatedbowlingleagueexample`.`bowlers` on((`updatedbowlingleagueexample`.`teams`.`CaptainID` = `updatedbowlingleagueexample`.`bowlers`.`BowlerID`)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch08_tournament_match_game_results`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch08_tournament_match_game_results`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch08_tournament_match_game_results` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyID` AS `Tourney`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `Location`,`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`tourney_matches`.`Lanes` AS `Lanes`,`oddteam`.`TeamName` AS `OddLaneTeam`,`eventeam`.`TeamName` AS `EvenLaneTeam`,`updatedbowlingleagueexample`.`match_games`.`GameNumber` AS `GameNo`,`winner`.`TeamName` AS `Winner` from (((((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`teams` `oddteam` on((`oddteam`.`TeamID` = `updatedbowlingleagueexample`.`tourney_matches`.`OddLaneTeamID`))) join `updatedbowlingleagueexample`.`teams` `eventeam` on((`eventeam`.`TeamID` = `updatedbowlingleagueexample`.`tourney_matches`.`EvenLaneTeamID`))) join `updatedbowlingleagueexample`.`match_games` on((`updatedbowlingleagueexample`.`match_games`.`MatchID` = `updatedbowlingleagueexample`.`tourney_matches`.`MatchID`))) join `updatedbowlingleagueexample`.`teams` `winner` on((`winner`.`TeamID` = `updatedbowlingleagueexample`.`match_games`.`WinningTeamID`)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch09_all_bowlers_and_scores_over_180`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch09_all_bowlers_and_scores_over_180`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch09_all_bowlers_and_scores_over_180` AS select concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `BowlerName`,`ti`.`TourneyDate` AS `TourneyDate`,`ti`.`TourneyLocation` AS `TourneyLocation`,`ti`.`MatchID` AS `MatchID`,`ti`.`RawScore` AS `RawScore` from (`updatedbowlingleagueexample`.`bowlers` left join (select `updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`bowler_scores`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` AS `RawScore` from ((`updatedbowlingleagueexample`.`bowler_scores` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`bowler_scores`.`MatchID` = `updatedbowlingleagueexample`.`tourney_matches`.`MatchID`))) join `updatedbowlingleagueexample`.`tournaments` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) where (`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` > 180)) `ti` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `ti`.`BowlerID`))) order by concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`);

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch09_all_tourneys_match_results`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch09_all_tourneys_match_results`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch09_all_tourneys_match_results` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyID` AS `TourneyID`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`tm`.`MatchID` AS `MatchID`,`tm`.`GameNumber` AS `GameNumber`,`tm`.`Winner` AS `Winner` from (`updatedbowlingleagueexample`.`tournaments` left join (select `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID` AS `TourneyID`,`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`match_games`.`GameNumber` AS `GameNumber`,`updatedbowlingleagueexample`.`teams`.`TeamName` AS `Winner` from (`updatedbowlingleagueexample`.`tourney_matches` join (`updatedbowlingleagueexample`.`teams` join `updatedbowlingleagueexample`.`match_games` on((`updatedbowlingleagueexample`.`teams`.`TeamID` = `updatedbowlingleagueexample`.`match_games`.`WinningTeamID`))) on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`match_games`.`MatchID`)))) `tm` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `tm`.`TourneyID`))) order by `updatedbowlingleagueexample`.`tournaments`.`TourneyID`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch09_matches_not_played_yet`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch09_matches_not_played_yet`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch09_matches_not_played_yet` AS select `updatedbowlingleagueexample`.`tourney_matches`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`tourney_matches`.`TourneyID` AS `TourneyID`,`updatedbowlingleagueexample`.`teams`.`TeamName` AS `OddLaneTeam`,`teams_1`.`TeamName` AS `EvenLaneTeam` from (`updatedbowlingleagueexample`.`teams` `teams_1` join (`updatedbowlingleagueexample`.`teams` join (`updatedbowlingleagueexample`.`tourney_matches` left join `updatedbowlingleagueexample`.`match_games` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`match_games`.`MatchID`))) on((`updatedbowlingleagueexample`.`teams`.`TeamID` = `updatedbowlingleagueexample`.`tourney_matches`.`OddLaneTeamID`))) on((`teams_1`.`TeamID` = `updatedbowlingleagueexample`.`tourney_matches`.`EvenLaneTeamID`))) where (`updatedbowlingleagueexample`.`match_games`.`MatchID` is null);

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch09_tourney_not_yet_played`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch09_tourney_not_yet_played`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch09_tourney_not_yet_played` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyID` AS `TourneyID`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation` from (`updatedbowlingleagueexample`.`tournaments` left join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) where (`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` is null);

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch10_bowling_schedule`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch10_bowling_schedule`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch10_bowling_schedule` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`teams`.`TeamName` AS `TeamName`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `Captain`,'Odd Lane' AS `Lane` from (((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`teams` on((`updatedbowlingleagueexample`.`teams`.`TeamID` = `updatedbowlingleagueexample`.`tourney_matches`.`OddLaneTeamID`))) join `updatedbowlingleagueexample`.`bowlers` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`teams`.`CaptainID`))) union all select `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`teams`.`TeamName` AS `TeamName`,concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `Captain`,'Even Lane' AS `Lane` from (((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`teams` on((`updatedbowlingleagueexample`.`teams`.`TeamID` = `updatedbowlingleagueexample`.`tourney_matches`.`EvenLaneTeamID`))) join `updatedbowlingleagueexample`.`bowlers` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`teams`.`CaptainID`))) order by `TourneyDate`,`MatchID`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_union`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_union`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_union` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` AS `RawScore` from (`updatedbowlingleagueexample`.`bowlers` join ((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) where ((`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Thunderbird Lanes') and (`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` > 165)) union select `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` AS `RawScore` from (`updatedbowlingleagueexample`.`bowlers` join ((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) where ((`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Bolero Lanes') and (`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` > 150));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_where`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_where`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch10_good_bowlers_tbird_bolero_where` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` AS `RawScore` from (`updatedbowlingleagueexample`.`tournaments` join (`updatedbowlingleagueexample`.`bowlers` join (`updatedbowlingleagueexample`.`tourney_matches` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) where (((`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Thunderbird Lanes') and (`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` > 165)) or ((`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Bolero Lanes') and (`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` > 150)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch11_bowler_high_score`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch11_bowler_high_score`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch11_bowler_high_score` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,(select max(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) from `updatedbowlingleagueexample`.`bowler_scores` where (`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` = `updatedbowlingleagueexample`.`bowlers`.`BowlerID`)) AS `HighScore` from `updatedbowlingleagueexample`.`bowlers`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch11_bowlers_and_count_games`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch11_bowlers_and_count_games`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch11_bowlers_and_count_games` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,(select count(0) from `updatedbowlingleagueexample`.`bowler_scores` where (`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` = `updatedbowlingleagueexample`.`bowlers`.`BowlerID`)) AS `Games` from `updatedbowlingleagueexample`.`bowlers`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch11_bowlers_low_score`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch11_bowlers_low_score`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch11_bowlers_low_score` AS select distinct `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` AS `RawScore` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) where `updatedbowlingleagueexample`.`bowler_scores`.`RawScore` < all (select `bs2`.`RawScore` from (`updatedbowlingleagueexample`.`bowlers` `b2` join `updatedbowlingleagueexample`.`bowler_scores` `bs2` on((`b2`.`BowlerID` = `bs2`.`BowlerID`))) where ((`b2`.`BowlerID` <> `updatedbowlingleagueexample`.`bowlers`.`BowlerID`) and (`b2`.`TeamID` = `updatedbowlingleagueexample`.`bowlers`.`TeamID`)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch11_team_captains_high_score`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch11_team_captains_high_score`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch11_team_captains_high_score` AS select `updatedbowlingleagueexample`.`teams`.`TeamName` AS `TeamName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` AS `HandiCapScore` from ((`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`teams` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`teams`.`CaptainID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) where `updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` > all (select `bs2`.`HandiCapScore` from (`updatedbowlingleagueexample`.`bowlers` `b2` join `updatedbowlingleagueexample`.`bowler_scores` `bs2` on((`b2`.`BowlerID` = `bs2`.`BowlerID`))) where ((`b2`.`BowlerID` <> `updatedbowlingleagueexample`.`bowlers`.`BowlerID`) and (`b2`.`TeamID` = `updatedbowlingleagueexample`.`bowlers`.`TeamID`)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch12_better_than_overall_average`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch12_better_than_overall_average`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch12_better_than_overall_average` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName` from `updatedbowlingleagueexample`.`bowlers` where ((select avg(`bs`.`RawScore`) from `updatedbowlingleagueexample`.`bowler_scores` `bs` where (`bs`.`BowlerID` = `updatedbowlingleagueexample`.`bowlers`.`BowlerID`)) >= (select avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) from `updatedbowlingleagueexample`.`bowler_scores`)) order by `updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch12_current_highest_handicap`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch12_current_highest_handicap`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch12_current_highest_handicap` AS select max(round(((200 - round((select avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) from `updatedbowlingleagueexample`.`bowler_scores` where (`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` = `updatedbowlingleagueexample`.`bowlers`.`BowlerID`)),0)) * 0.9),0)) AS `HighHandicap` from `updatedbowlingleagueexample`.`bowlers`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch12_last_tourney_date`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch12_last_tourney_date`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch12_last_tourney_date` AS select max(`updatedbowlingleagueexample`.`tournaments`.`TourneyDate`) AS `MostRecentDate` from `updatedbowlingleagueexample`.`tournaments`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch12_number_of_tournaments_at_red_rooster_lanes`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch12_number_of_tournaments_at_red_rooster_lanes`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch12_number_of_tournaments_at_red_rooster_lanes` AS select count(`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation`) AS `NumberOfTournaments` from `updatedbowlingleagueexample`.`tournaments` where (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Red Rooster Lanes');

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch12_tourney_locations_for_earliest_date`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch12_tourney_locations_for_earliest_date`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch12_tourney_locations_for_earliest_date` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation` from `updatedbowlingleagueexample`.`tournaments` where (`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` = (select min(`updatedbowlingleagueexample`.`tournaments`.`TourneyDate`) from `updatedbowlingleagueexample`.`tournaments`));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch13_bowler_average_handicap`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch13_bowler_average_handicap`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch13_bowler_average_handicap` AS select `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,sum(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) AS `TotalPins`,count(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) AS `GamesBowled`,round(avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`),0) AS `CurAvg`,round((0.9 * (200 - round(avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`),0))),0) AS `CurHcp` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) group by `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch13_bowler_averages`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch13_bowler_averages`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch13_bowler_averages` AS select concat(`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,', ',`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) AS `BowlerFullName`,avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) AS `AvgOfRawScore` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) group by `updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch13_bowler_high_score_group`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch13_bowler_high_score_group`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch13_bowler_high_score_group` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,max(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) AS `HighScore` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) group by `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch13_bowler_high_score_subquery`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch13_bowler_high_score_subquery`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch13_bowler_high_score_subquery` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,(select max(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) from `updatedbowlingleagueexample`.`bowler_scores` where (`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` = `updatedbowlingleagueexample`.`bowlers`.`BowlerID`)) AS `HighScore` from `updatedbowlingleagueexample`.`bowlers`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch13_tournament_match_team_results`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch13_tournament_match_team_results`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch13_tournament_match_team_results` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyID` AS `TourneyID`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`teams`.`TeamName` AS `TeamName`,sum(`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore`) AS `TotHandiCapScore` from (((((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`match_games` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`match_games`.`MatchID`))) join `updatedbowlingleagueexample`.`bowler_scores` on(((`updatedbowlingleagueexample`.`match_games`.`GameNumber` = `updatedbowlingleagueexample`.`bowler_scores`.`GameNumber`) and (`updatedbowlingleagueexample`.`match_games`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`)))) join `updatedbowlingleagueexample`.`bowlers` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) join `updatedbowlingleagueexample`.`teams` on((`updatedbowlingleagueexample`.`teams`.`TeamID` = `updatedbowlingleagueexample`.`bowlers`.`TeamID`))) group by `updatedbowlingleagueexample`.`tournaments`.`TourneyID`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation`,`updatedbowlingleagueexample`.`tourney_matches`.`MatchID`,`updatedbowlingleagueexample`.`teams`.`TeamName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch14_better_than_overall_average_having`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch14_better_than_overall_average_having`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch14_better_than_overall_average_having` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) group by `updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` having (avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) >= (select avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) from `updatedbowlingleagueexample`.`bowler_scores`));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch14_bowlers_big_high_score`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch14_bowlers_big_high_score`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch14_bowlers_big_high_score` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,round(avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`),0) AS `CurrentAverage`,max(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) AS `HighGame` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) group by `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` having (max(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) > (round(avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`),0) + 20));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch14_captains_who_are_hotshots`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch14_captains_who_are_hotshots`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch14_captains_who_are_hotshots` AS select `updatedbowlingleagueexample`.`teams`.`TeamID` AS `TeamID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,max(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) AS `MaxOfRawScore` from ((`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) join `updatedbowlingleagueexample`.`teams` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`teams`.`CaptainID`))) group by `updatedbowlingleagueexample`.`teams`.`TeamID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` having (max(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) > (select max(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) from ((`updatedbowlingleagueexample`.`teams` `t2` join `updatedbowlingleagueexample`.`bowlers` `b2` on((`t2`.`TeamID` = `b2`.`TeamID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`b2`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) where ((`t2`.`TeamID` = `updatedbowlingleagueexample`.`teams`.`TeamID`) and (`b2`.`BowlerID` <> `updatedbowlingleagueexample`.`bowlers`.`BowlerID`))));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch14_good_bowlers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch14_good_bowlers`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch14_good_bowlers` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) AS `AvgScore` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) group by `updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` having (avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) > 155);

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch18_bowlers_lte_165_thunderbird_bolero`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch18_bowlers_lte_165_thunderbird_bolero`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch18_bowlers_lte_165_thunderbird_bolero` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName` from `updatedbowlingleagueexample`.`bowlers` where `updatedbowlingleagueexample`.`bowlers`.`BowlerID` in (select `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` from ((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) where ((`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` > 165) and (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` in ('Thunderbird Lanes','Bolero Lanes')))) is false;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_right`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_right`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_right` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowler_scores`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`bowler_scores`.`GameNumber` AS `GameNumber`,`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` AS `HandiCapScore`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation` from (((`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`bowler_scores`.`MatchID` = `updatedbowlingleagueexample`.`tourney_matches`.`MatchID`))) join `updatedbowlingleagueexample`.`tournaments` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) where ((`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` <= 190) and (`updatedbowlingleagueexample`.`bowler_scores`.`WonGame` = 1) and (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` in ('Thunderbird Lanes','Totem Lanes','Bolero Lanes')) and `updatedbowlingleagueexample`.`bowlers`.`BowlerID` in (select `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` from ((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) where ((`updatedbowlingleagueexample`.`bowler_scores`.`WonGame` = 1) and (`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` <= 190) and (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Thunderbird Lanes'))) and `updatedbowlingleagueexample`.`bowlers`.`BowlerID` in (select `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` from ((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) where ((`updatedbowlingleagueexample`.`bowler_scores`.`WonGame` = 1) and (`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` <= 190) and (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Totem Lanes'))) and `updatedbowlingleagueexample`.`bowlers`.`BowlerID` in (select `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` from ((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) where ((`updatedbowlingleagueexample`.`bowler_scores`.`WonGame` = 1) and (`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` <= 190) and (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Bolero Lanes'))));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_wrong`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_wrong`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch18_bowlers_won_lowscore_tbird_totem_bolero_wrong` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowler_scores`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`bowler_scores`.`GameNumber` AS `GameNumber`,`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` AS `HandiCapScore`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation` from (((`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`bowler_scores`.`MatchID` = `updatedbowlingleagueexample`.`tourney_matches`.`MatchID`))) join `updatedbowlingleagueexample`.`tournaments` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) where ((`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` <= 190) and (`updatedbowlingleagueexample`.`bowler_scores`.`WonGame` = 1) and (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` in ('Thunderbird Lanes','Totem Lanes','Bolero Lanes')));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch18_good_bowlers_tbird_and_bolero_exists`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch18_good_bowlers_tbird_and_bolero_exists`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch18_good_bowlers_tbird_and_bolero_exists` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName` from `updatedbowlingleagueexample`.`bowlers` where (exists(select 1 from ((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) where ((`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` = `updatedbowlingleagueexample`.`bowlers`.`BowlerID`) and (`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` >= 170) and (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Thunderbird Lanes'))) and exists(select 1 from ((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `updatedbowlingleagueexample`.`bowler_scores`.`MatchID`))) where ((`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` = `updatedbowlingleagueexample`.`bowlers`.`BowlerID`) and (`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` >= 170) and (`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` = 'Bolero Lanes'))));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch18_mediocre_bowlers`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch18_mediocre_bowlers`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch18_mediocre_bowlers` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName` from `updatedbowlingleagueexample`.`bowlers` where exists(select 1 from `updatedbowlingleagueexample`.`bowler_scores` where ((`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` > 150) and (`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` = `updatedbowlingleagueexample`.`bowlers`.`BowlerID`))) is false;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch18_tourney_not_yet_played_not_in`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch18_tourney_not_yet_played_not_in`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch18_tourney_not_yet_played_not_in` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyID` AS `TourneyID`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation` from `updatedbowlingleagueexample`.`tournaments` where `updatedbowlingleagueexample`.`tournaments`.`TourneyID` in (select `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID` from `updatedbowlingleagueexample`.`tourney_matches`) is false;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch19_all_tournaments_any_matches`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch19_all_tournaments_any_matches`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch19_all_tournaments_any_matches` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyID` AS `TourneyID`,`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,(case when (`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` is null) then 'Not Played Yet' else concat('Match: ',cast(`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` as char charset utf8mb4),'  Lanes: ',convert(`updatedbowlingleagueexample`.`tourney_matches`.`Lanes` using utf8mb4),'  Odd Lane Team: ',convert(`updatedbowlingleagueexample`.`teams`.`TeamName` using utf8mb4),'  Even Lane Team: ',convert(`teams_1`.`TeamName` using utf8mb4)) end) AS `MatchInfo` from (`updatedbowlingleagueexample`.`tournaments` left join ((`updatedbowlingleagueexample`.`tourney_matches` join `updatedbowlingleagueexample`.`teams` on((`updatedbowlingleagueexample`.`tourney_matches`.`OddLaneTeamID` = `updatedbowlingleagueexample`.`teams`.`TeamID`))) join `updatedbowlingleagueexample`.`teams` `teams_1` on((`updatedbowlingleagueexample`.`tourney_matches`.`EvenLaneTeamID` = `teams_1`.`TeamID`))) on((`updatedbowlingleagueexample`.`tourney_matches`.`TourneyID` = `updatedbowlingleagueexample`.`tournaments`.`TourneyID`)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch19_all_tourney_matches`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch19_all_tourney_matches`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch19_all_tourney_matches` AS select `updatedbowlingleagueexample`.`tournaments`.`TourneyDate` AS `TourneyDate`,`updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` AS `TourneyLocation`,`updatedbowlingleagueexample`.`tourney_matches`.`Lanes` AS `Lanes`,`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`teams`.`TeamName` AS `OddLaneTeam`,`teams_1`.`TeamName` AS `EvenLaneTeam`,`gameresults`.`GameNumber` AS `GameNumber`,(case when (`gameresults`.`TeamName` is null) then 'Match not played' else `gameresults`.`TeamName` end) AS `Winner` from ((((`updatedbowlingleagueexample`.`tournaments` join `updatedbowlingleagueexample`.`tourney_matches` on((`updatedbowlingleagueexample`.`tournaments`.`TourneyID` = `updatedbowlingleagueexample`.`tourney_matches`.`TourneyID`))) join `updatedbowlingleagueexample`.`teams` on((`updatedbowlingleagueexample`.`tourney_matches`.`OddLaneTeamID` = `updatedbowlingleagueexample`.`teams`.`TeamID`))) join `updatedbowlingleagueexample`.`teams` `teams_1` on((`updatedbowlingleagueexample`.`tourney_matches`.`EvenLaneTeamID` = `teams_1`.`TeamID`))) left join (select `updatedbowlingleagueexample`.`match_games`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`match_games`.`GameNumber` AS `GameNumber`,`teams_2`.`TeamName` AS `TeamName` from (`updatedbowlingleagueexample`.`match_games` join `updatedbowlingleagueexample`.`teams` `teams_2` on((`updatedbowlingleagueexample`.`match_games`.`WinningTeamID` = `teams_2`.`TeamID`)))) `gameresults` on((`updatedbowlingleagueexample`.`tourney_matches`.`MatchID` = `gameresults`.`MatchID`))) order by `updatedbowlingleagueexample`.`tournaments`.`TourneyDate`,`updatedbowlingleagueexample`.`tourney_matches`.`MatchID`,`gameresults`.`GameNumber`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch19_bowler_averages_avoid_0_games`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch19_bowler_averages_avoid_0_games`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch19_bowler_averages_avoid_0_games` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,count(`updatedbowlingleagueexample`.`bowler_scores`.`MatchID`) AS `GamesBowled`,sum(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) AS `TotalPins`,(case count(`updatedbowlingleagueexample`.`bowler_scores`.`MatchID`) when 0 then 0 else cast((sum(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) / count(`updatedbowlingleagueexample`.`bowler_scores`.`MatchID`)) as signed) end) AS `BowlerAverage` from (`updatedbowlingleagueexample`.`bowlers` left join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) group by `updatedbowlingleagueexample`.`bowlers`.`BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch19_bowler_ratings`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch19_bowler_ratings`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch19_bowler_ratings` AS select `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,cast(avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) as signed) AS `BowlerAverage`,(case when (cast(avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) as signed) < 140) then 'Fair' when (cast(avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) as signed) < 160) then 'Average' when (cast(avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) as signed) < 185) then 'Good' else 'Excellent' end) AS `BowlerRating` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) group by `updatedbowlingleagueexample`.`bowlers`.`BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch20_bowler_mailing_skip_3`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch20_bowler_mailing_skip_3`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch20_bowler_mailing_skip_3` AS select ' ' AS `BowlerLastName`,' ' AS `BowlerFirstName`,' ' AS `BowlerAddress`,' ' AS `BowlerCity`,' ' AS `BowlerState`,' ' AS `BowlerZip` from `updatedbowlingleagueexample`.`ztblskiplabels` where (`updatedbowlingleagueexample`.`ztblskiplabels`.`LabelCount` <= 3) union all select `updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerAddress` AS `BowlerAddress`,`updatedbowlingleagueexample`.`bowlers`.`BowlerCity` AS `BowlerCity`,`updatedbowlingleagueexample`.`bowlers`.`BowlerState` AS `BowlerState`,`updatedbowlingleagueexample`.`bowlers`.`BowlerZip` AS `BowlerZip` from `updatedbowlingleagueexample`.`bowlers` order by `BowlerZip`,`BowlerLastName`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch20_bowler_ratings`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch20_bowler_ratings`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch20_bowler_ratings` AS select `bscores`.`BowlerID` AS `BowlerID`,`bscores`.`BowlerLastName` AS `BowlerLastName`,`bscores`.`BowlerFirstName` AS `BowlerFirstName`,`bscores`.`BowlerAverage` AS `BowlerAverage`,`updatedbowlingleagueexample`.`ztblbowlerratings`.`BowlerRating` AS `BowlerRating` from (`updatedbowlingleagueexample`.`ztblbowlerratings` join (select `updatedbowlingleagueexample`.`bowlers`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName` AS `BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName` AS `BowlerFirstName`,cast(avg(`updatedbowlingleagueexample`.`bowler_scores`.`RawScore`) as signed) AS `BowlerAverage` from (`updatedbowlingleagueexample`.`bowlers` join `updatedbowlingleagueexample`.`bowler_scores` on((`updatedbowlingleagueexample`.`bowlers`.`BowlerID` = `updatedbowlingleagueexample`.`bowler_scores`.`BowlerID`))) group by `updatedbowlingleagueexample`.`bowlers`.`BowlerID`,`updatedbowlingleagueexample`.`bowlers`.`BowlerLastName`,`updatedbowlingleagueexample`.`bowlers`.`BowlerFirstName`) `bscores`) where (`bscores`.`BowlerAverage` between `updatedbowlingleagueexample`.`ztblbowlerratings`.`BowlerLowAvg` and `updatedbowlingleagueexample`.`ztblbowlerratings`.`BowlerHighAvg`);

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch20_team_pairings`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch20_team_pairings`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch20_team_pairings` AS select `updatedbowlingleagueexample`.`teams`.`TeamID` AS `Team1ID`,`updatedbowlingleagueexample`.`teams`.`TeamName` AS `Team1Name`,`teams_1`.`TeamID` AS `Team2ID`,`teams_1`.`TeamName` AS `Team2Name` from (`updatedbowlingleagueexample`.`teams` join `updatedbowlingleagueexample`.`teams` `teams_1`) where (`teams_1`.`TeamID` > `updatedbowlingleagueexample`.`teams`.`TeamID`) order by `updatedbowlingleagueexample`.`teams`.`TeamID`,`teams_1`.`TeamID`;

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch20_tournament_week_schedule_2017`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch20_tournament_week_schedule_2017`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch20_tournament_week_schedule_2017` AS select `updatedbowlingleagueexample`.`ztblweeks`.`WeekStart` AS `WeekStart`,(select `updatedbowlingleagueexample`.`tournaments`.`TourneyLocation` from `updatedbowlingleagueexample`.`tournaments` where (`updatedbowlingleagueexample`.`tournaments`.`TourneyDate` between `updatedbowlingleagueexample`.`ztblweeks`.`WeekStart` and `updatedbowlingleagueexample`.`ztblweeks`.`WeekEnd`)) AS `BowlingAlley` from `updatedbowlingleagueexample`.`ztblweeks` where ((`updatedbowlingleagueexample`.`ztblweeks`.`WeekStart` <= cast('2017-12-31' as date)) and (`updatedbowlingleagueexample`.`ztblweeks`.`WeekEnd` >= cast('2017-09-01' as date)));

-- -----------------------------------------------------
-- View `updatedbowlingleagueexample`.`ch4_ble_2`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `updatedbowlingleagueexample`.`ch4_ble_2`;
USE `updatedbowlingleagueexample`;
CREATE  OR REPLACE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `updatedbowlingleagueexample`.`ch4_ble_2` AS select `updatedbowlingleagueexample`.`bowler_scores`.`MatchID` AS `MatchID`,`updatedbowlingleagueexample`.`bowler_scores`.`GameNumber` AS `GameNumber`,`updatedbowlingleagueexample`.`bowler_scores`.`BowlerID` AS `BowlerID`,`updatedbowlingleagueexample`.`bowler_scores`.`RawScore` AS `RawScore`,`updatedbowlingleagueexample`.`bowler_scores`.`HandiCapScore` AS `HandiCapScore`,`updatedbowlingleagueexample`.`bowler_scores`.`WonGame` AS `WonGame` from `updatedbowlingleagueexample`.`bowler_scores`;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
